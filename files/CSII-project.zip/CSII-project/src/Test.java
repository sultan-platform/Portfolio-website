import java.util.Scanner;

public class Test {
    public static void main(String[] args) {
        Library library = new Library();
        Scanner sc = new Scanner(System.in);

        int choice;

        do {
            choice = displayMenu(sc);
            switch (choice) {
                case 1:
                    System.out.print("Enter the pathname of the file to read: ");
                    String readPath = sc.nextLine();
                    library.readFromFile(readPath);
                    break;
                case 2:
                    System.out.print("Enter book type (E for EBook, P for PrintedBook): ");
                    String type = sc.nextLine().toUpperCase();

                    System.out.print("Enter title: ");
                    String title = sc.nextLine();

                    System.out.print("Enter author: ");
                    String author = sc.nextLine();

                    if (type.equals("E")) {
                        System.out.print("Enter file size (MB): ");
                        double size = sc.nextDouble();
                        sc.nextLine(); // consume newline
                        library.addBook(new EBook(title, author, size));
                    } else if (type.equals("P")) {
                        System.out.print("Enter number of pages: ");
                        int pages = sc.nextInt();
                        sc.nextLine(); // consume newline
                        library.addBook(new PrintedBook(title, author, pages));
                    } else {
                        System.out.println("Invalid book type.");
                    }
                    break;
                case 3:
                    System.out.print("Enter title of the book to remove: ");
                    String removeTitle = sc.nextLine();
                    if (library.removeBook(removeTitle)) {
                        System.out.println("Book was removed.");
                    } else {
                        System.out.println("Book was not found.");
                    }
                    break;
                case 4:
                    System.out.print("Enter title of the book to search: ");
                    String searchTitle = sc.nextLine();
                    Book found = library.searchBook(searchTitle);
                    if (found != null) {
                        System.out.println("Found: " + found);
                    } else {
                        System.out.println("Book was not found.");
                    }
                    break;
                case 5:
                    library.displayBooks();
                    break;
                case 6:
                    System.out.print("Enter the pathname of the file to save: ");
                    String writePath = sc.nextLine();
                    library.writeToFile(writePath);
                    System.out.println("Exiting program.");
                    break;
                default:
                    System.out.println("Invalid choice.");
            }

        } while (choice !=6);
    }
    public static int displayMenu(Scanner sc) {
        try {
            System.out.println("\nLibrary Management System Menu");
            System.out.println("------------------------------");
            System.out.println("1. Read all books from file");
            System.out.println("2. Add a new book");
            System.out.println("3. Remove a book");
            System.out.println("4. Search for a book");
            System.out.println("5. Display all books");
            System.out.println("6. Save to file and exit");
            System.out.println("------------------------------");
            System.out.print("Enter your choice (1 to 6): ");
            return Integer.parseInt(sc.nextLine());
        }catch (NumberFormatException ex){
            System.out.println("Invalid input. Please enter a number from 1 to 6."+ex);
            return -1;
        }
    }
}
