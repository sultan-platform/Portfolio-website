import java.util.*;
import java.io.*;

public class Library {
    private ArrayList<Book> books = new ArrayList<>();

    public void addBook(Book b) {
        books.add(b);
    }

    public boolean removeBook(String title) {
        for (Book b : books) {
            if (b.getTitle().equalsIgnoreCase(title)) {
                books.remove(b);
                return true;
            }
        }
        return false;
    }

    public Book searchBook(String title) {
        for (Book b : books) {
            if (b.getTitle().equalsIgnoreCase(title)) {
                return b;
            }
        }
        return null;
    }

    public void displayBooks() {
        if (books.isEmpty()) {
            System.out.println("No books in the library.");
        } else {
            for (Book b : books) {
                System.out.println(b);
            }
        }
    }

    public void readFromFile(String pathname) {
        try (Scanner scanner = new Scanner(new File(pathname))) {
            while (scanner.hasNextLine()) {
                String line = scanner.nextLine();
                String[] parts = line.split(",", 3);
                if (parts.length < 3) continue;

                String type = parts[0].trim();
                String title = parts[1].trim();
                String authorAndRest = parts[2].trim();

                if (type.startsWith("E")) {
                    String[] sub = authorAndRest.split(",", 2);
                    String author = sub[0].trim();
                    double size = Double.parseDouble(sub[1].replace("Mbytes", "").trim());
                    addBook(new EBook(title, author, size));
                } else if (type.startsWith("P")) {
                    String[] sub = authorAndRest.split(",", 2);
                    String author = sub[0].trim();
                    int pages = Integer.parseInt(sub[1].replace("pages", "").trim());
                    addBook(new PrintedBook(title, author, pages));
                }
            }
            System.out.println("Books loaded successfully.");
        } catch (FileNotFoundException e) {
            System.out.println("File not found.");
        } catch (Exception e) {
            System.out.println("Error reading file: " + e.getMessage());
        }
    }

    public void writeToFile(String pathname) {
        try (PrintWriter writer = new PrintWriter(new File(pathname))) {
            for (Book b : books) {
                if (b instanceof EBook) {
                    EBook eb = (EBook) b;
                    writer.println("E, " + eb.getTitle() + ", " + eb.getAuthor() + ", " + eb.getFileSize() + " Mbytes");
                } else if (b instanceof PrintedBook) {
                    PrintedBook pb = (PrintedBook) b;
                    writer.println("P, " + pb.getTitle() + ", " + pb.getAuthor() + ", " + pb.getNumPages() + " pages");
                }
            }
            System.out.println("Books saved successfully.");
        } catch (Exception e) {
            System.out.println("Error writing file: " + e.getMessage());
        }
    }
}
