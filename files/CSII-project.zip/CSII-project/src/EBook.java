public class EBook extends Book{
    private double fileSize;     //in megabytes
    public EBook(String title, String author, double fileSize){
        super(title, author);
        this.fileSize = fileSize;
    }

    public double getFileSize() {
        return fileSize;
    }
    public void setFileSize(double fileSize) {
        this.fileSize = fileSize;
    }

    @Override
    public String toString() {
        return "Book title: " + getTitle() +
                ", Book author: " + getAuthor() +
                ", File size: " + fileSize + " Megabytes";
    }
}
