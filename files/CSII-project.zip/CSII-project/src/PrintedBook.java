public class PrintedBook extends Book{
    private int numPages;
    public PrintedBook(String title, String author, int numPages){
        super(title, author);
        this.numPages = numPages;

    }
    public int getNumPages() {
        return numPages;
    }

    public void setNumPages(int numPages) {
        this.numPages = numPages;
    }
    @Override
    public String toString(){
        return "Book title: " + getTitle() +
                ", Book author: " + getAuthor() +
                ", Number of printed book pages: " + numPages;
    }
}
